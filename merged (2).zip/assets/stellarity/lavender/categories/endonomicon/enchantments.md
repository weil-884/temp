```json
{
  "title": "Enchantments",
  "icon": "minecraft:enchanted_book"
}
```

Stellarity adds a handful of new enchantments into the game.